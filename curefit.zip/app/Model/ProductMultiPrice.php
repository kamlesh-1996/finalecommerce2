<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProductMultiPrice extends Model
{
    public $table = 'product_multi_pricies';
}
